#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct date
{
    int j;
    int m;
    int a;
}date;

typedef struct mesure
{
    char id[20];
    int type;
    char marque[20];
    char etage[5];
    float valeur;
    date d;
    int h;
    int m;
}mesure;


typedef struct capteur
{
    char id[20];
    int type;
    char bloc[2];
    char marque[20];
    date d;
}capteur;

void ajouterc(capteur u, char *fname);
void supprimerc(capteur u, char *fname);
void modifierc(capteur u, char *fname);
void afficherc(GtkWidget *liste, char *fname);
void defectueuxc(GtkWidget *liste, char *fname);
void ajouter_mesurec(mesure u, char *fname);

