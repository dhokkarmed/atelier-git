#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <gtk/gtk.h>
#include <string.h>
#include <time.h>

typedef struct Datee 
{
int jour,mois,annee;
}Datee;

typedef struct etudiant {

        int id;
        char prenom[20];
        char nom[20];
        Datee d;
	char bloc[2];
        int chambre;
        int tel;
        int niveau;

}etudiant;


void ajouter_hebergement(etudiant e, char *fname);
void supprimer_hebergement(etudiant e, char *fname);
void afficher_hebergement(GtkWidget *liste, char *fname);
void modifier_hebergement(etudiant e, char *fname);
etudiant chercher_hebergement(int id, char *fname);
char* nombre_etudiant(char *fname);
