#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include "fonction_nour.h"
#include "CRUD.h"
#include "tree.h"
#include "capteur.h"
#include "produit.h"
#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




void
on_buttonAJOUTERtest_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *ajtest, *Maintest;
Maintest=lookup_widget(objet,"Maintest");
ajtest=lookup_widget(objet,"ajtest");
ajtest=create_ajtest();
gtk_widget_show(ajtest);


}


void
on_buttonMODIFIERtest_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *modtest, *Maintest;
Maintest=lookup_widget(objet,"Maintest");
modtest=lookup_widget(objet,"modtest");
modtest=create_modtest();
gtk_widget_show(modtest);
}


void
on_buttonAFFICHERtest_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeviewtest, *aftest, *Maintest;
aftest=lookup_widget(objet,"aftest");
aftest=create_aftest();
gtk_widget_show(aftest);
treeviewtest=lookup_widget(aftest,"treeviewtest");
affichertest(treeviewtest,"stock.txt");
}


void
on_button4test_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
 /*GtkWidget *b, *pInfo;
char str[1000], ch[1000]="";
strcpy(ch,rupture_stock("stock.txt"));
b=lookup_widget(objet,"button4");
sprintf(str,"%s",ch);
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,str);
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}*/
GtkWidget *treeviewtest, *Rupturetest;
Rupturetest=lookup_widget(objet,"Rupturetest");
gtk_widget_destroy(Rupturetest);
Rupturetest=lookup_widget(objet,"Rupturetest");
Rupturetest= create_Rupturetest ();
gtk_widget_show(Rupturetest);
treeviewtest=lookup_widget(Rupturetest,"treeview1test");
afficher_ruptest(treeviewtest,"stock.txt");
}


void
on_valider_mtest_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *m1test, *m2test,*comboboxm3test, *pInfotest;
produit u;
m1test=lookup_widget(objet,"m1test");
m2test=lookup_widget(objet,"m2test");
comboboxm3test=lookup_widget(objet,"comboboxm3test");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(m1test)));
u.quantite=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m2test));
strcpy(u.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxm3test)));
modifiertest(u,"stock.txt");
pInfotest=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Produit modifié avec succès");
	switch(gtk_dialog_run(GTK_DIALOG(pInfotest)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfotest);
	break;
	}
}


void
on_check_iddtest_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *m1test, *m2test, *comboboxm3test, *pInfotest;
produit p;
int b=0;
int a=0;
char ch1[20], ch2[20], id[20];
FILE *f;
m1test=lookup_widget(objet,"m1test");
m2test=lookup_widget(objet,"m2test");
comboboxm3test=lookup_widget(objet,"comboboxm3test");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(m1test)));
f = fopen("stock.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %f %s\n",p.id,&(p.quantite),p.type)!=EOF)
	{
		if(strcmp(p.id,id)==0){
			a=1;
			break;
                 }
	}
fclose(f);
}

if(strcmp(p.type,"boissons")==0)
b=0;
else if(strcmp(p.type,"produits_laitiers")==0)
b=1;
else if(strcmp(p.type,"fruits")==0)
b=2;
else if(strcmp(p.type,"légumes")==0)
b=3;
else if(strcmp(p.type,"féculents")==0)
b=4;
else if(strcmp(p.type,"viandes")==0)
b=5;
else if(strcmp(p.type,"poissons")==0)
b=6;



if(a==1){
sprintf(ch1,"%.2f",p.quantite);
gtk_entry_set_text(GTK_ENTRY(m2test),ch1);
gtk_combo_box_set_active(GTK_COMBO_BOX(comboboxm3test),b);
}
else{
pInfotest=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Produit introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(pInfotest)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfotest);
	break;
	}
}
}


void
on_afficheraftest_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeviewtest, *aftest;
aftest=lookup_widget(objet,"aftest");
gtk_widget_destroy(aftest);
aftest=lookup_widget(objet,"aftest");
aftest=create_aftest();
gtk_widget_show(aftest);
treeviewtest=lookup_widget(aftest,"treeviewtest");
affichertest(treeviewtest,"stock.txt");
}


void
on_valider_ruptest_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *a1test, *a2test, *comboboxa3test;
produit u;
a1test=lookup_widget(objet,"a1test");
a2test=lookup_widget(objet,"a2test");
comboboxa3test=lookup_widget(objet,"comboboxa3test");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(a1test)));
u.quantite=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a2test));
strcpy(u.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxa3test)));
ajoutertest(u,"stock.txt");
}


void
on_treeviewtest_row_activated              (GtkTreeView     *treeviewtest,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar *id;
	produit u;
	GtkWidget *pInfo;
	GtkTreeModel *model=gtk_tree_view_get_model(treeviewtest);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
	strcpy(u.id,id);
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer ce produit?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimertest(u,"stock.txt");
	affichertest(treeviewtest,"stock.txt");
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;
}	
}
}


void
on_terminertest_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *Rupturetest;
 GtkWidget *Maintest;
Maintest=lookup_widget(objet,"Maintest");
Rupturetest=lookup_widget(objet,"Rupturetest");
gtk_widget_hide(Rupturetest);

}


void
on_retourmtest_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *modtest, *Maintest;
modtest=lookup_widget(objet,"modtest");
gtk_widget_destroy(modtest);
Maintest=lookup_widget(objet,"Maintest");
Maintest=create_Maintest();
gtk_widget_show(Maintest);
}









void
on_retouraftest_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *aftest, *Maintest;
aftest=lookup_widget(objet,"aftest");
gtk_widget_destroy(aftest);
Maintest=lookup_widget(objet,"Maintest");
Maintest=create_Maintest();
gtk_widget_show(Maintest);
}


void
on_retourruptest_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajtest, *Maintest;
ajtest=lookup_widget(objet,"ajtest");
gtk_widget_destroy(ajtest);
Maintest=lookup_widget(objet,"Maintest");
Maintest=create_Maintest();
gtk_widget_show(Maintest);
}

void
on_button8test_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *Rupturetest, *Maintest;
Rupturetest=lookup_widget(objet,"Rupturetest");
gtk_widget_destroy(Rupturetest);
Maintest=lookup_widget(objet,"Maintest");
Maintest=create_Maintest();
gtk_widget_show(Maintest);
}




void
on_button1capp_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *aj, *dashboard;
dashboard=lookup_widget(objet,"dashboard");
aj=lookup_widget(objet,"aj");
aj=create_aj();
gtk_widget_show(aj);


}


void
on_button2capp_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod, *dashboard;
dashboard=lookup_widget(objet,"dashboard");
mod=lookup_widget(objet,"mod");
mod=create_mod();
gtk_widget_show(mod);
}


void
on_button3capp_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af;
af=lookup_widget(objet,"af");
af=create_af();
gtk_widget_show(af);
treeview=lookup_widget(af,"treeviewm");
afficherc(treeview,"capteurs.txt");
}


void
on_button4capp_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *def, *treeview;
def=lookup_widget(objet,"def");
def=create_def();
gtk_widget_show(def);
treeview=lookup_widget(def,"treeview_defm");
defectueuxc(treeview,"mesures.txt");
}


void
on_button_modcapp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1m, *mod2m, *mod3m, *pInfo, *mod4m;
capteur u;
mod1m=lookup_widget(objet,"mod1m");
mod2m=lookup_widget(objet,"mod2m");
mod3m=lookup_widget(objet,"mod3m");
mod4m=lookup_widget(objet,"mod4m");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(mod1m)));
u.type=gtk_combo_box_get_active(GTK_COMBO_BOX(mod2m));
strcpy(u.bloc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(mod4m)));
strcpy(u.marque,gtk_entry_get_text(GTK_ENTRY(mod3m)));
modifierc(u,"capteurs.txt");
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Capteur modifié avec succès");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}


void
on_check_idcapp_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1m, *mod2m, *mod3m, *pInfo, *mod4m;
capteur p;
int a=0;
char id[50];
FILE *f;
mod1m=lookup_widget(objet,"mod1m");
mod2m=lookup_widget(objet,"mod2m");
mod3m=lookup_widget(objet,"mod3m");
mod4m=lookup_widget(objet,"mod4m");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(mod1m)));
f = fopen("capteurs.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %d %s %s %d %d %d\n",p.id,&(p.type),p.bloc,p.marque,&(p.d.j),&(p.d.m),&(p.d.a))!=EOF)
	{
		if(strcmp(p.id,id)==0){
			a=1;
			break;
                 }
	}
fclose(f);
}
if(a==1){
gtk_combo_box_set_active(GTK_COMBO_BOX(mod2m),p.type);
gtk_entry_set_text(GTK_ENTRY(mod3m),p.marque);
gtk_combo_box_set_active(GTK_COMBO_BOX(mod4m),strcmp(p.bloc,"A")==0?0:strcmp(p.bloc,"B")==0?1:2);
}
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Capteur introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
}


void
on_button_afcapp_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeviewm, *af;
af=lookup_widget(objet,"af");
gtk_widget_destroy(af);
af=lookup_widget(objet,"af");
af=create_af();
gtk_widget_show(af);
treeviewm=lookup_widget(af,"treeviewm");
afficherc(treeviewm,"capteurs.txt");
}


void
on_button_ajcapp_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj1m, *aj2m, *aj3m, *am, *bm, *cm;
GtkCalendar *ajcm;
capteur u;
guint day, month, year;
aj1m=lookup_widget(objet,"aj1m");
aj2m=lookup_widget(objet,"aj2m");
aj3m=lookup_widget(objet,"aj3m");
ajcm=lookup_widget(objet,"ajcm");
am=lookup_widget(objet,"aj4m");
bm=lookup_widget(objet,"aj5m");
cm=lookup_widget(objet,"aj6m");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(aj1m)));
u.type=gtk_combo_box_get_active(GTK_COMBO_BOX(aj2m));
strcpy(u.bloc,gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(am))?"A":gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bm))?"B":"C");
strcpy(u.marque,gtk_entry_get_text(GTK_ENTRY(aj3m)));
gtk_calendar_get_date(GTK_CALENDAR(ajcm), &day, &month, &year);
u.d.j=year;
u.d.m=month+1;
u.d.a=day;
ajouterc(u,"capteurs.txt");
}


void
on_treeviewcapp_row_activated              (GtkTreeView     *treeviewm,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar *id;
	capteur u;
	GtkWidget *pInfo;
	GtkTreeModel *model=gtk_tree_view_get_model(treeviewm);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
	strcpy(u.id,id);
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer ce capteur?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimerc(u,"capteurs.txt");
	afficherc(treeviewm,"capteurs.txt");
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;
}	
}
}


void
on_button_ajmcapp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj1m, *aj2m, *aj3m, *aj4m, *aj5m, *hm, *mm;
GtkCalendar *ajcm;
mesure u;
guint day, month, year;
aj1m=lookup_widget(objet,"ajm1m");
aj2m=lookup_widget(objet,"ajm2m");
aj3m=lookup_widget(objet,"ajm3m");
aj4m=lookup_widget(objet,"ajm4m");
aj5m=lookup_widget(objet,"ajm5m");
ajcm=lookup_widget(objet,"ajmcm");
hm=lookup_widget(objet,"hm");
mm=lookup_widget(objet,"mm");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(aj1m)));
u.type=gtk_combo_box_get_active(GTK_COMBO_BOX(aj2m));
strcpy(u.marque,gtk_entry_get_text(GTK_ENTRY(aj3m)));
strcpy(u.etage,gtk_entry_get_text(GTK_ENTRY(aj4m)));
u.valeur=atof(gtk_entry_get_text(GTK_ENTRY(aj5m)));
gtk_calendar_get_date(GTK_CALENDAR(ajcm), &day, &month, &year);
u.d.j=year;
u.d.m=month+1;
u.d.a=day;
u.h=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(hm));
u.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm));
ajouter_mesurec(u,"mesures.txt");
}


void
on_affichercapp_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeviewm, *def;
def=lookup_widget(objet,"def");
gtk_widget_destroy(def);
def=lookup_widget(objet,"def");
def=create_def();
gtk_widget_show(def);
treeviewm=lookup_widget(def,"treeview_defm");
defectueuxc(treeviewm,"mesures.txt");
}


void
on_ajoutercapp_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj_mesure, *def;
def=lookup_widget(objet,"def");
aj_mesure=lookup_widget(objet,"aj_mesure");
aj_mesure=create_aj_mesure();
gtk_widget_show(aj_mesure);
}


void
on_suppcapp_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *sup1m;
capteur u;
sup1m=lookup_widget(objet,"sup1m");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(sup1m)));
supprimerc(u,"capteurs.txt");
}





///////////////////////////////////////////////////////////////////////////////////////////////////////////// Mohamed

GtkTreeSelection *selection1;
GtkWidget *principale ;
void
on_AcceuilGestionw_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
/*preparation du treeView*/
GtkWidget *p;
GtkWidget *principale;
gtk_widget_hide (principale);
gestionw = create_gestionw ();
p=lookup_widget(gestionw,"treeview2w");
Affichermenu(p,"menu.txt");
gtk_widget_show (gestionw);
}


void
on_Ajoutermenu_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
 menu t;
GtkWidget *entrytempsw;
GtkWidget *entryIdw;

GtkWidget *entryDatew;
GtkWidget *entryentreew;
GtkWidget *labelIdw;
GtkWidget *labeltempsw;




GtkWidget *labeldessert;






GtkWidget *labelDatew;
GtkWidget *labelentreew;
GtkWidget *existew;
GtkWidget* successw;
GtkWidget *calw;
GtkWidget *entrymenu;
GtkWidget *labelmenu;
GtkWidget *entrydessert;
GtkWidget *input7,*input8,*input9;


int b=1;
int jj1,mm1,aa1;
char date[50];
FILE*f=NULL;


entryIdw=lookup_widget(gestionw,"entry5w");
entrytempsw=lookup_widget(gestionw,"combobox1w");

entrymenu=lookup_widget(gestionw,"entrymenu");
entrydessert=lookup_widget(gestionw,"entrydessert");




input7=lookup_widget(button,"spinbuttonjour"); 
input8=lookup_widget(button,"spinbuttonmois");
input9=lookup_widget(button,"spinbuttonannee");


entryentreew=lookup_widget(gestionw,"entry3w");

labelIdw=lookup_widget(gestionw,"label13w");
labeltempsw=lookup_widget(gestionw,"label7w");



labeldessert=lookup_widget(gestionw,"labeldessert");





labelmenu=lookup_widget(gestionw,"labellabel");


labelentreew=lookup_widget(gestionw,"label10w");
existew=lookup_widget(gestionw,"label34w");
successw=lookup_widget(gestionw,"label35w");

        strcpy(t.id,gtk_entry_get_text(GTK_ENTRY(entryIdw) ) );
        strcpy(t.temps,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrytempsw)));
        

        strcpy(t.entree,gtk_entry_get_text(GTK_ENTRY(entryentreew) ) );
        strcpy(t.menu_principal,gtk_entry_get_text(GTK_ENTRY(entrymenu) ) );
	strcpy(t.dessert,gtk_entry_get_text(GTK_ENTRY(entrydessert) ) );
	




 gtk_widget_hide (successw);





        t.date1.jour  = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
	t.date1.mois  = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
	t.date1.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9)); 
	
 gtk_widget_hide (successw);


// controle saisie
if(strcmp(t.id,"")==0){
		  gtk_widget_show (labelIdw);
b=0;
}
else {
		  gtk_widget_hide(labelIdw);
}

if(strcmp(t.temps,"")==0){
		  gtk_widget_show (labeltempsw);
b=0;
}
else {
		  gtk_widget_hide(labeltempsw);
}


if(strcmp(t.entree,"")==0){
		  gtk_widget_show (labelentreew);
b=0;
}
else {
		  gtk_widget_hide(labelentreew);
}

if(strcmp(t.menu_principal,"")==0){
		  gtk_widget_show (labelmenu);
b=0;
}
else {
		  gtk_widget_hide(labelmenu);
}





if(strcmp(t.dessert,"")==0){
		  gtk_widget_show (labeldessert);
b=0;
}
else {
		  gtk_widget_hide(labeldessert);
}









if(b==1){

        if(exist_menu(t.id)==1)
        {

				  gtk_widget_show (existew);
                }
                else {
                     gtk_widget_hide (existew);

       f=fopen("menu.txt","a+");

fprintf(f,"%s %s %d/%d/%d %s %s %s\n",t.id,t.temps,t.date1.jour,t.date1.mois,t.date1.annee,t.entree,t.menu_principal,t.dessert);
fclose(f);
     

                  gtk_widget_show (successw);



      GtkWidget* p=lookup_widget(gestionw,"treeview2w");

        Affichermenu(p,"menu.txt");
}

}
}



void
on_Modifiermenu_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
      GtkWidget *combobox3w;
        GtkWidget *combobox4w;
     combobox3w=lookup_widget(button,"combobox3w");
     combobox4w=lookup_widget(button,"combobox4w");
       	 menu t;

        strcpy(t.id,gtk_label_get_text(GTK_LABEL(lookup_widget(gestionw,"label20w"))));
        strcpy(t.temps,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lookup_widget(gestionw,"combobox3w"))));
        
        strcpy(t.entree,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestionw,"entry8w"))));
        strcpy(t.date,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestionw,"entry9w"))));
	strcpy(t.menu_principal,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestionw,"entryrec"))));
	strcpy(t.dessert,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestionw,"entrydes"))));
	



        supprimer_menu(t.id);
        ajouter_menu(t);
//mise ajour du tree view 
        Affichermenu(lookup_widget(gestionw,"treeview1"),"menu.txt");
	gtk_widget_show(lookup_widget(gestionw,"label37w"));
        GtkWidget *p=lookup_widget(gestionw,"treeview2w");
        Affichermenu(p,"menu.txt");
}





void
on_cherchermenu_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1w;
GtkWidget *entryw;
GtkWidget *labelidw;
GtkWidget *nbResultatw;
GtkWidget *messagew;
char id[30];
char chnb[30];
int b=0,nb;  
entryw=lookup_widget(gestionw,"entry10w");
labelidw=lookup_widget(gestionw,"label28w");
p1w=lookup_widget(gestionw,"treeview2w");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(entryw)));

if(strcmp(id,"")==0){
  gtk_widget_show (labelidw);b=0;
}else{
b=1;
gtk_widget_hide (labelidw);}

if(b==0)
    {return;
    }
    else
    {

nb=Cherchermenu(p1w,"menu.txt",id);

 

sprintf(chnb,"%d",nb);        
nbResultatw=lookup_widget(gestionw,"label27");
messagew=lookup_widget(gestionw,"label26w");
gtk_label_set_text(GTK_LABEL(nbResultatw),chnb);

gtk_widget_show (nbResultatw);
gtk_widget_show (messagew);
}
}


void
on_GestionAcceuilw_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (principale);
gtk_widget_destroy (gestionw);

}




void
on_bmodifier_clickedw                   (GtkButton       *button,
                                        gpointer         user_data)
{
        gchar *id;
        gchar *temps;
        gchar *date;
        gchar *entree;
	gchar *menu_principal;
	gchar *dessert;
	
  
        GtkTreeModel     *model;
        GtkTreeIter iter;
        if (gtk_tree_selection_get_selected(selection1, &model, &iter))
        {

        gtk_widget_hide(lookup_widget(gestionw,"label37w"));//cacher label modifier avec succees
                gtk_tree_model_get (model,&iter,0,&id,1,&temps,2,&date,3,&entree,4,&menu_principal,5,&dessert,-1);//recuperer les information de la ligne selectionneé



        
               
   
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestionw,"entry9w")),date);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestionw,"entry8w")),entree);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestionw,"entryrec")),menu_principal);
 gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestionw,"entrydes")),dessert);
 
                GtkWidget* msgId=lookup_widget(gestionw,"label20w");
                GtkWidget* msg1=lookup_widget(gestionw,"label36w");
                gtk_label_set_text(GTK_LABEL(msgId),id);
                gtk_widget_show(msgId);
                gtk_widget_show(msg1);
                gtk_widget_show(lookup_widget(gestionw,"button4w"));//afficher le bouton modifier
                gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(gestionw,"notebook1w")));
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestionw,"entry9w")),date);
                
             
        }

}


void
on_bsupprimer_clickedw                  (GtkButton       *button,
                                        gpointer         user_data)
{
    gchar *id;
    gchar *temps;
    
    gchar *date;
    gchar *entree;
    gchar *menu_principal;
    gchar *dessert;
    
    GtkTreeModel     *model;
    GtkTreeIter iter;
       if (gtk_tree_selection_get_selected(selection1, &model, &iter))
        {
            gtk_tree_model_get (model,&iter,0,&id,1,&temps,2,&date,3,&entree,4,&menu_principal,5,&dessert,-1);//recuperer les information de la ligne selectionneé
            supprimer_menu(id);
            Affichermenu(lookup_widget(gestionw,"treeview2w"),"menu.txt");        
        }
}


void
on_bafficher12w_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *p=lookup_widget(gestionw,"treeview2w");
        Affichermenu(p,"menu.txt");
}


void
on_treeview2w_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
    	gchar *id;
        gchar *temps;
        
        gchar *date;
        gchar *entree;
	gchar *menu_principal;
        gchar *dessert;
	
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(gestionw,"treeview2w");
        selection1 = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
       
}












int toggle;
char search[100];

void
on_accueil_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gerer_utilisateurs_principale;
GtkWidget *principale;

Gerer_utilisateurs_principale=lookup_widget(button,"Gerer_utilisateurs_principale");
gtk_widget_destroy(Gerer_utilisateurs_principale);
principale=lookup_widget(button,"principale");
principale=create_principale();
gtk_widget_show(principale);
}


void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
GtkWidget *Gerer_utilisateurs_principale;

treeview1=lookup_widget(button,"treeview1");
afficher(treeview1);
}


void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
utilisateurs u;
GtkWidget *username, *label1;
GtkWidget *treeview1;
GtkWidget *Gerer_utilisateurs_principale;
GtkWidget *pInfo;
GtkWidget *dialog1;

treeview1=lookup_widget(button,"treeview1");
username=lookup_widget(button, "chercher1"); 
strcpy(u.username,gtk_entry_get_text (GTK_ENTRY(username)));
label1=lookup_widget(button, "label36");

pInfo=gtk_message_dialog_new(GTK_WINDOW(dialog1),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer cet utilisateur?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimer(u.username);
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;

afficher(treeview1);
}
}

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char username[100];
GtkWidget *treeview,*filter,*label1;
treeview=lookup_widget(button,"treeview1");
filter=lookup_widget(button,"chercher1");
strcpy(username,gtk_entry_get_text(GTK_ENTRY(filter)));
if (verif(username)==0)
{
	rechercher(treeview,username);
label1=lookup_widget(button,"label36");
gtk_label_set_text(GTK_LABEL(label1),"nom d'utilisateur existe");
strcpy(search,username);
}
else
{
label1=lookup_widget(button,"label36");
gtk_label_set_text(GTK_LABEL(label1),"nom d'utilisateur \n n'existe pas");
}
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_alarme_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gerer_utilisateurs_principale;
GtkWidget *Gerer_utilisateurs_alarme;

Gerer_utilisateurs_principale=lookup_widget(button,"Gerer_utilisateurs_principale");

gtk_widget_destroy(Gerer_utilisateurs_principale); 
Gerer_utilisateurs_alarme=lookup_widget(button,"Gerer_utilisateurs_alarme");
Gerer_utilisateurs_alarme=create_Gerer_utilisateurs_alarme();

gtk_widget_show(Gerer_utilisateurs_alarme);
}


void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gerer_utilisateurs_principale;
GtkWidget *Gerer_utilisateurs_modifier;

Gerer_utilisateurs_principale=lookup_widget(button,"Gerer_utilisateurs_principale");

gtk_widget_destroy(Gerer_utilisateurs_principale); 
Gerer_utilisateurs_modifier=lookup_widget(button,"Gerer_utilisateurs_modifier");
Gerer_utilisateurs_modifier=create_Gerer_utilisateurs_modifier();

gtk_widget_show(Gerer_utilisateurs_modifier);
}


void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gerer_utilisateurs_principale;
GtkWidget *Gerer_utilisateurs_ajout;

Gerer_utilisateurs_principale=lookup_widget(button,"Gerer_utilisateurs_principale");

gtk_widget_destroy(Gerer_utilisateurs_principale); 
Gerer_utilisateurs_ajout=lookup_widget(button,"Gerer_utilisateurs_ajout");
Gerer_utilisateurs_ajout=create_Gerer_utilisateurs_ajout();

gtk_widget_show(Gerer_utilisateurs_ajout);
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	{
		toggle=1;
	}
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	{
		toggle=2;
	}
}


void
on_retourner_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gerer_utilisateurs_principale;
GtkWidget *Gerer_utilisateurs_ajout;
GtkWidget *treeview1;

treeview1=lookup_widget(button,"treeview1");
Gerer_utilisateurs_ajout=lookup_widget(button,"Gerer_utilisateurs_ajout");

gtk_widget_destroy(Gerer_utilisateurs_ajout); 
Gerer_utilisateurs_principale=lookup_widget(button,"Gerer_utilisateurs_principale");
Gerer_utilisateurs_principale=create_Gerer_utilisateurs_principale();

gtk_widget_show(Gerer_utilisateurs_principale);
afficher(treeview1);
}


void
on_add_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{
utilisateurs u;
GtkWidget *nom, * prenom, *username, *password, *role, *identifiant, *jour, *mois, *annee, *gender, *field, *label;
nom=lookup_widget (button, "nom"); 
prenom=lookup_widget(button, "prenom");
username=lookup_widget(button, "user"); 
password=lookup_widget (button, "mdp");
identifiant=lookup_widget(button, "identifiant");
field=lookup_widget(button, "section");
jour=lookup_widget (button, "jour"); 
mois=lookup_widget (button, "mois");
annee=lookup_widget (button, "annee");
role=lookup_widget (button, "comboboxentry1"); 
strcpy(u.nom,gtk_entry_get_text (GTK_ENTRY (nom))); 
strcpy(u.prenom,gtk_entry_get_text (GTK_ENTRY (prenom))); 
strcpy(u.username,gtk_entry_get_text (GTK_ENTRY(username))); 
strcpy(u.password,gtk_entry_get_text (GTK_ENTRY (password)));
strcpy(u.identifiant,gtk_entry_get_text(GTK_ENTRY(identifiant)));
strcpy(u.field,gtk_entry_get_text(GTK_ENTRY(field)));
u.dob.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
u.dob.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois)); 
u.dob.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee)); 
strcpy(u.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)));
label=lookup_widget(button, "label24");
if(toggle==1)
{strcpy(u.gender,"Male");}
else
{strcpy(u.gender,"Female");}

if((strlen(u.identifiant)!=8)||(strcmp(u.nom,"")==0)||(strcmp(u.prenom,"")==0)||(strcmp(u.username,"")==0)||(strcmp(u.password,"")==0)||(strcmp(u.field,"")==0))
	{	
		gtk_label_set_text(GTK_LABEL(label),"complétez vos données");}

else if(verif(u.username)==1)
{ajouter(u);
gtk_label_set_text(GTK_LABEL(label),"Ajout avec succé");
}
else
gtk_label_set_text(GTK_LABEL(label),"Mot de utilisateur déja éxiste");
}


void
on_retourner1_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gerer_utilisateurs_principale;
GtkWidget *Gerer_utilisateurs_modifier;
GtkWidget *treeview1;

treeview1=lookup_widget(button,"treeview1");
Gerer_utilisateurs_modifier=lookup_widget(button,"Gerer_utilisateurs_modifier");

gtk_widget_destroy(Gerer_utilisateurs_modifier); 
Gerer_utilisateurs_principale=lookup_widget(button,"Gerer_utilisateurs_principale");
Gerer_utilisateurs_principale=create_Gerer_utilisateurs_principale();

gtk_widget_show(Gerer_utilisateurs_principale);
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_afficher1_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview2;

treeview2=lookup_widget(button,"treeview2");
afficher1(treeview2);
}


void
on_retourner2_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gerer_utilisateurs_principale;
GtkWidget *Gerer_utilisateurs_alarme;

Gerer_utilisateurs_alarme=lookup_widget(button,"Gerer_utilisateurs_alarme");

gtk_widget_destroy(Gerer_utilisateurs_alarme); 
Gerer_utilisateurs_principale=lookup_widget(button,"Gerer_utilisateurs_principale");
Gerer_utilisateurs_principale=create_Gerer_utilisateurs_principale();

gtk_widget_show(Gerer_utilisateurs_principale);
}


void
on_Actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
utilisateurs a;
GtkWidget *nom,*prenom,*username,*identifiant,*label81,*check;
char check1[50];

nom=lookup_widget(button,"nom_modif");
prenom=lookup_widget(button,"prenom_modif");
username=lookup_widget(button,"user_modif");
identifiant=lookup_widget(button,"entry4");
check=lookup_widget(button,"entry5");
strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(a.username,gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(identifiant)));
strcpy(check1,gtk_entry_get_text(GTK_ENTRY(check)));

if((strcmp(a.prenom,"")==0)||(strcmp(a.username,"")==0)||(strcmp(a.nom,"")==0)||(strlen(a.identifiant)!=8))
	{	
		gtk_label_set_text(GTK_LABEL(label81),"complétez vos données");
	}
else
{	
	modifier(check1,a.nom,a.prenom,a.username,a.identifiant);
}
label81=lookup_widget(button,"label81");
gtk_label_set_text(GTK_LABEL(label81),"Done");
}


void //ajouter un étudiant à l'hebergement
on_button1_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj_hebergement, *dashboard_hebergement;


dashboard_hebergement=lookup_widget(objet,"dashboard_hebergement");


aj_hebergement=lookup_widget(objet,"aj_hebergement");
aj_hebergement=create_aj_hebergement();

gtk_widget_show(aj_hebergement);
}


void  //modifier un étudiant à l'hebergement
on_button2_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod_hebergement, *dashboard_hebergement;


dashboard_hebergement=lookup_widget(objet,"dashboard_hebergement");


mod_hebergement=lookup_widget(objet,"mod_hebergement");
mod_hebergement=create_mod_hebergement();

gtk_widget_show(mod_hebergement);
}


void //afficher un étudiant à l'hebergement
on_button3_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview3, *af_hebergement, *dashboard_hebergement;


dashboard_hebergement=lookup_widget(objet,"dashboard_hebergement");


af_hebergement=lookup_widget(objet,"af_hebergement");
af_hebergement=create_af_hebergement();

gtk_widget_show(af_hebergement);

treeview3=lookup_widget(af_hebergement,"treeview3");

afficher_hebergement(treeview3,"hebergement.txt");
}



void //chercher un étudiants 
on_button4_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *recherche, *dashboard_hebergement;


dashboard_hebergement=lookup_widget(objet,"dashboard_hebergement");


recherche=lookup_widget(objet,"recherche");
recherche=create_recherche();

gtk_widget_show(recherche);
}


void //chercher étudiant hebergement
on_button5_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *pInfo, *b;
b=lookup_widget(objet,"button4");
char str[1000], ch[1000]="";
strcpy(ch,nombre_etudiant("hebergement.txt"));
sprintf(str,"%s",ch);
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,str);
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	} 


}


void //suppresion d'un etudiant
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gint id;
	etudiant e;
	GtkWidget *pInfo;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
	e.id=id;
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer cet étudiant?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimer_hebergement(e,"hebergement.txt");
	afficher_hebergement(treeview,"hebergement.txt");
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;
}	
}
}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}

 
void //modifier etudiant hebergement
on_check_id_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *mod4, *mod5, *mod6, *pInfo, *bloc1, *bloc2, *bloc3;
etudiant p;
int a=0;
char ch[20];
FILE *f;
mod1=lookup_widget(objet,"mod1");
mod2=lookup_widget(objet,"mod2");
mod3=lookup_widget(objet,"mod3");
bloc1=lookup_widget(objet,"modA");
bloc2=lookup_widget(objet,"modB");
bloc3=lookup_widget(objet,"modC");
mod4=lookup_widget(objet,"mod4");
mod5=lookup_widget(objet,"mod5");
mod6=lookup_widget(objet,"mod6");
int id = atoi(gtk_entry_get_text(GTK_ENTRY(mod1)));
f = fopen("hebergement.txt","r");
if(f!=NULL){
while(fscanf(f,"%d %s %s %d %d %d %s %d %d %d\n",&(p.id),p.prenom,p.nom,&(p.d.jour),&(p.d.mois),&(p.d.annee),p.bloc,&(p.chambre),&(p.tel),&(p.niveau))!=EOF)
	{
		if(p.id==id){
			a=1;
			break;
                 }
	}
fclose(f);
}
if(a==1){
gtk_entry_set_text(GTK_ENTRY(mod2),p.prenom);
gtk_entry_set_text(GTK_ENTRY(mod3),p.nom);
strcmp(p.bloc,"A")==0?gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(bloc1),TRUE):strcmp(p.bloc,"B")==0?gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(bloc2),TRUE):gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(bloc3),TRUE);
gtk_combo_box_set_active(GTK_COMBO_BOX(mod4),p.chambre-1);
sprintf(ch,"%d",p.tel);
gtk_entry_set_text(GTK_ENTRY(mod5),ch);
gtk_combo_box_set_active(GTK_COMBO_BOX(mod6),p.niveau-1);
}
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Etudiant introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
}

 
void //ajouter etudiant hebergement
on_button_aj_clicked                   (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj1, *aj2, *aj3, *aj4, *aj5, *aj6, *bloc1, *bloc2, *bloc3;
GtkCalendar *ajc;
etudiant e;
int c;
guint day, month, year;
aj1=lookup_widget(objet,"aj1");
aj2=lookup_widget(objet,"aj2");
aj3=lookup_widget(objet,"aj3");
ajc=lookup_widget(objet,"ajc");
bloc1=lookup_widget(objet,"ajA");
bloc2=lookup_widget(objet,"ajB");
bloc3=lookup_widget(objet,"ajC");
aj4=lookup_widget(objet,"aj4");
aj5=lookup_widget(objet,"aj5");
aj6=lookup_widget(objet,"aj6");
e.id=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(aj1));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(aj2)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(aj3)));
gtk_calendar_get_date(GTK_CALENDAR(ajc), &day, &month, &year);
e.d.jour=year;
e.d.mois=month+1;
e.d.annee=day;
strcpy(e.bloc,gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc1))==1?"A":gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc2))==1?"B":"C");
c=gtk_combo_box_get_active(GTK_COMBO_BOX(aj4));
e.chambre = c==0?1:c==1?2:3;
e.tel=atoi(gtk_entry_get_text(GTK_ENTRY(aj5)));
e.niveau = gtk_combo_box_get_active(GTK_COMBO_BOX(aj6))+1;
ajouter_hebergement(e,"hebergement.txt");
}



void
on_chercher_etudiant_clicked           (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *r1, *r2, *r3, *r4, *r5, *r6, *r7, *r8, *pInfo;
char date_naissance[20], tel[20], niveau[20];
r1=lookup_widget(objet,"r1");
r2=lookup_widget(objet,"r2");
r3=lookup_widget(objet,"r3");
r4=lookup_widget(objet,"r4");
r5=lookup_widget(objet,"r5");
r6=lookup_widget(objet,"r6");
r7=lookup_widget(objet,"r7");
r8=lookup_widget(objet,"r8");
int id = atoi(gtk_entry_get_text(GTK_ENTRY(r1)));
etudiant p = chercher_hebergement(id,"hebergement.txt");
if (p.id==-1){
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"ID introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
else{
gtk_label_set_text(GTK_LABEL(r2),p.prenom);
gtk_label_set_text(GTK_LABEL(r3),p.nom);
sprintf(date_naissance,"%d/%d/%d",p.d.jour,p.d.mois,p.d.annee);
gtk_label_set_text(GTK_LABEL(r4),date_naissance);
gtk_label_set_text(GTK_LABEL(r5),p.bloc);
gtk_label_set_text(GTK_LABEL(r6),p.chambre==1?"Individuelle":p.chambre==2?"Double":"Triple");
sprintf(tel,"%d",p.tel);
gtk_label_set_text(GTK_LABEL(r7),tel);
sprintf(niveau,(p.niveau>0&&p.niveau<6)?(p.niveau==1?"1ère année":"%déme année"):"Non spécifié",p.niveau);
gtk_label_set_text(GTK_LABEL(r8),niveau);
}
}


void
on_button_mod_clicked                  (GtkButton        *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *mod4, *mod5, *mod6, *bloc1, *bloc2, *bloc3, *pInfo;
etudiant e;
int c;
mod1=lookup_widget(objet,"mod1");
mod2=lookup_widget(objet,"mod2");
mod3=lookup_widget(objet,"mod3");
bloc1=lookup_widget(objet,"modA");
bloc2=lookup_widget(objet,"modB");
bloc3=lookup_widget(objet,"modC");
mod4=lookup_widget(objet,"mod4");
mod5=lookup_widget(objet,"mod5");
mod6=lookup_widget(objet,"mod6");
e.id=atoi(gtk_entry_get_text(GTK_ENTRY(mod1)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(mod2)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(mod3)));
strcpy(e.bloc,gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc1))==1?"A":gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc2))==1?"B":"C");
e.chambre=gtk_combo_box_get_active(GTK_COMBO_BOX(mod4))+1;
e.tel=atoi(gtk_entry_get_text(GTK_ENTRY(mod5)));
e.niveau=gtk_combo_box_get_active(GTK_COMBO_BOX(mod6))+1;
modifier_hebergement(e,"hebergement.txt");
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Etudiant modifié avec succès");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}


void
on_actualiser_etudiant_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_technicien_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dashboard;
GtkWidget *principale;
gtk_widget_hide (principale);
dashboard = create_dashboard ();

gtk_widget_show (dashboard);
}


void
on_button_nutritionniste_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Maintest;
GtkWidget *principale;
gtk_widget_hide (principale);
Maintest = create_Maintest ();

gtk_widget_show (Maintest);
}


void
on_button_agent_restaurant_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_agent_foyer_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dashboard_hebergement;
GtkWidget *principale;


dashboard_hebergement=lookup_widget(button,"dashboard_hebergement");
dashboard_hebergement=create_dashboard_hebergement();
gtk_widget_show(dashboard_hebergement);
}


void
on_button_admin_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gerer_utilisateurs_principale;
GtkWidget *principale;


Gerer_utilisateurs_principale=lookup_widget(button,"Gerer_utilisateurs_principale");
Gerer_utilisateurs_principale=create_Gerer_utilisateurs_principale();
gtk_widget_show(Gerer_utilisateurs_principale);

}


void
on_principale_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_refresh_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
FILE *f=NULL;
int b=0;
char check1[50];
utilisateurs a;
GtkWidget *nom,*prenom,*username,*identifiant,*label81,*check;

check=lookup_widget(button,"entry5");
nom=lookup_widget(button,"nom_modif");
prenom=lookup_widget(button,"prenom_modif");
username=lookup_widget(button,"user_modif");
identifiant=lookup_widget(button,"entry4");
strcpy(check1,gtk_entry_get_text(GTK_ENTRY(check)));
f = fopen("user.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s  %s\n",a.nom,a.prenom,a.username,a.password,a.role,a.identifiant,&a.dob.jour,&a.dob.mois,&a.dob.annee,a.gender,a.field)!=EOF)
	 {	
			if (strcmp(a.username,check1)==0)
			{
				gtk_entry_set_text(GTK_ENTRY(nom),a.nom);
				gtk_entry_set_text(GTK_ENTRY(prenom),a.prenom);
				gtk_entry_set_text(GTK_ENTRY(username),a.username);
				gtk_entry_set_text(GTK_ENTRY(identifiant),a.identifiant);
				b=1;
			break;
                 }
	}
fclose(f);
}
if(b==1)
{
label81=lookup_widget(button,"label81");
	gtk_label_set_text(GTK_LABEL(label81),"Voila les champs \n à modifiers");	
}
else 	{
	label81=lookup_widget(button,"label81");
	gtk_label_set_text(GTK_LABEL(label81),"n'existe pas");
	}
}

