#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include "callbacks.h"
#include<string.h>

//Ajouter un menu 

void ajouter_menu( menu t){
FILE*f=NULL; //flot de donnée
f=fopen("menu.txt","a+");// creation du fichier menu .txt et ouverture en  mode lecture et ecriture a la fin
fprintf(f,"%s %s %s %s %s %s\n",t.id,t.temps,t.date,t.entree,t.menu_principal,t.dessert); //f variable de type file 
fclose(f);
 //retour NULL si operation fini 
}
//********************************************************





//verifier l'existance 

int exist_menu(char*id){
FILE*f=NULL;
menu t;
f=fopen("menu.txt","r");// ouverture du fichier menu en  mode lecture 
while(fscanf(f,"%s %s %s %s %s %s\n",t.id,t.temps,t.date,t.entree,t.menu_principal,t.dessert)!=EOF){
if(strcmp(t.id,id)==0)
return 1;   //id existe deja 
}
fclose(f);
return 0;
}

//*****************************************************************




//supprimer tr
void supprimer_menu(char*id){
FILE*f=NULL;
FILE*f1=NULL;
menu t ;
f=fopen("menu.txt","r");
f1=fopen("ancien.txt","w+");//mode lecture et ecriture 
while(fscanf(f,"%s %s %s %s %s %s\n",t.id,t.temps,t.date,t.entree,t.menu_principal,t.dessert)!=EOF){
if(strcmp(id,t.id)!=0)
fprintf(f1,"%s %s %s %s %s %s\n",t.id,t.temps,t.date,t.entree,t.menu_principal,t.dessert);
}
fclose(f);
fclose(f1);
remove("menu.txt");
rename("ancien.txt","menu.txt");
}

//******************************************************************
















