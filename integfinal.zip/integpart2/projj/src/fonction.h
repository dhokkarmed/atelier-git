#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <gtk/gtk.h>
#include <string.h>
#include <time.h>






typedef struct Date 
{
int jour,mois,annee;
}Date;
typedef struct utilisateurs
{
 	char nom[100];
	char prenom[100];
	char username[100];
	char password[100];
	char role[100];
	char identifiant[100];
	Date dob;
	char gender[100];
	char field[100];
}utilisateurs;




void ajouter(utilisateurs a);
int verif(char username[]);
void modifier(char id1[],char ch1[],char ch2[],char ch3[],char ch4[]);
void supprimer(char username[]);
void rechercher(GtkWidget *liste,char username[]);
void afficher(GtkWidget *liste);






//#endif








