#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

typedef struct produit
{
    char id[20];
    float quantite;
    char type[20];
}produit;

void ajoutertest(produit u, char *fname);
void supprimertest(produit u, char *fname);
void modifiertest(produit u, char *fname);
void affichertest(GtkWidget *liste, char *fname);
void afficher_ruptest(GtkWidget *liste, char *fname);

