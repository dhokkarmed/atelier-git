#include <gtk/gtk.h>
#include <gtk/gtk.h>
  GtkWidget *acceuilw;
  GtkWidget *gestionw;


void
on_buttonAJOUTERtest_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonMODIFIERtest_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonAFFICHERtest_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button4test_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider_mtest_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_check_iddtest_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficheraftest_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider_ruptest_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeviewtest_row_activated              (GtkTreeView     *treeviewtest,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_terminertest_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourmtest_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retouraftest_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retourruptest_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button8test_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);




void
on_retourruptest_clicked               (GtkButton       *objet,
                                        gpointer         user_data);
void
on_button1capp_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_button2capp_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_button3capp_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_button4capp_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_button_modcapp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_check_idcapp_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_button_afcapp_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_button_ajcapp_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_treeviewcapp_row_activated              (GtkTreeView     *treeviewm,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
void
on_button_ajmcapp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_affichercapp_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_ajoutercapp_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_suppcapp_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);
struct Date1
{
int jour;
int mois;
int annee;
}Date1;


typedef struct menu menu ;
struct menu{
char id[30];
char temps[30];
char date[30];
char entree[30];
char menu_principal[50];
char dessert[50];

struct Date1 date1;
};

int i,j ;

void
on_AcceuilGestionw_clicked              (GtkButton       *button,
                                        gpointer         user_data);


void
on_GestionAcceuilw_clicked              (GtkButton       *button,
                                        gpointer         user_data);


void
on_bmodifier_clickedw                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_bsupprimer_clickedw                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_bafficher12w_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2w_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_cherchermenu_clicked          (GtkButton       *button,
                                        gpointer         user_data);



void
on_Ajoutermenu_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifiermenu_clicked           (GtkButton       *button,
                                        gpointer         user_data);



void
on_GestionAcceuilw_clicked             (GtkButton       *button,
                                        gpointer         user_data);



void
on_accueil_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_alarme_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_retourner_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_add_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourner1_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_afficher1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourner2_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_Actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_id_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_aj_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_id_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_etudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_mod_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_etudiant_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_technicien_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_nutritionniste_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_agent_restaurant_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_agent_foyer_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_admin_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_principale_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_refresh_clicked                     (GtkButton       *button,
                                        gpointer         user_data);



