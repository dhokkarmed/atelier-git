#include <gtk/gtk.h>
void ajouter_menu(menu t );

int exist_menu(char*id);
void supprimer_menu(char*id);
