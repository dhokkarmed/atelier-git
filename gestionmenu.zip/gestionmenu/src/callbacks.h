#include <gtk/gtk.h>
  GtkWidget *acceuilw;
  GtkWidget *gestionw;

struct Date1
{
int jour;
int mois;
int annee;
}Date1;


typedef struct menu menu ;
struct menu{
char id[30];
char temps[30];
char date[30];
char entree[30];
char menu_principal[50];
char dessert[50];

struct Date1 date1;
};

int i,j ;

void
on_AcceuilGestionw_clicked              (GtkButton       *button,
                                        gpointer         user_data);


void
on_GestionAcceuilw_clicked              (GtkButton       *button,
                                        gpointer         user_data);


void
on_bmodifier_clickedw                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_bsupprimer_clickedw                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_bafficher12w_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2w_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_cherchermenu_clicked          (GtkButton       *button,
                                        gpointer         user_data);



void
on_Ajoutermenu_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifiermenu_clicked           (GtkButton       *button,
                                        gpointer         user_data);



void
on_GestionAcceuilw_clicked             (GtkButton       *button,
                                        gpointer         user_data);



